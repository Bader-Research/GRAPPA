#ifndef GETOPT3_H
#define GETOPT3_H

#ifdef CYGWIN_NT_40
int getopt(int argc, char *argv[], char *opts);
#endif

#endif
